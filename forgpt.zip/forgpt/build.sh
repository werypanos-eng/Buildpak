#!/usr/bin/env bash

# ================================================================================
# Telegram bot: t.me/imguisource_bot
# Telegram channel (ImGui Source): t.me/ImGui_Source_FIXNEY
# Telegram channel (shit src 🧨): t.me/il2cpp_src
# ================================================================================

set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
exec "$ROOT/scripts/build.sh" "$@"
