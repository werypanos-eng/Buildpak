#!/bin/bash
DIR="/data/local/tmp/forgpt/jni"
echo "[*] Переименовываем проект в $DIR..."

# 1. Меняем имя модуля в Android.mk
sed -i 's/LOCAL_MODULE := .*/LOCAL_MODULE := Kakashoika/' $DIR/Android.mk

# 2. Ищем и меняем все упоминания Ximira в коде C++
grep -rl "Ximira" $DIR/src | xargs sed -i 's/Ximira/Kakashoika/g'
grep -rl "ximira" $DIR/src | xargs sed -i 's/ximira/kakashoika/g'

echo "[+] Готово! Все упоминания заменены."
