# game

offsets.hpp contains the 1.1.0 ARM64 profile for the supplied libunity.so (GNU Build ID 69815f2befe135c2). Camera mappings and native entry evidence are recorded in port/. Some unused historical fields remain; see README_1.1.0_RU.md for disabled or unsupported features.
